package pistonunitfactory;

import carcylinderfactory.Cylinder;

public class Piston {
	
	//
	Cylinder cyn;
	//
	
	public Piston (Cylinder c) {
		System.out.println("Piston ctor");
		cyn = c;
	}
}
