
interface Shape
{
	void draw();
}
class Circle implements Shape
{
	public void draw() {
		System.out.println("Circle is drawn..");
	}
}
class Rectangle implements Shape
{
	public void draw() {
		System.out.println("Rectangle is drawn..");
	}
}

class Triangle implements Shape
{
	public void draw() {
		System.out.println("Triangle is drawn..");
	}
}

class DrawingApplication
{
		//here shape is injected inside this method
	static void drawShape(Shape shape) {
		shape.draw(); //which shape would be drawn???
	}
}

public class ShapeTest {
	public static void main(String[] args) {
		Circle c = new Circle();
		Rectangle r= new Rectangle();
		Triangle t = new Triangle();
	
		DrawingApplication.drawShape(t);
	}
}
