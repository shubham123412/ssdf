package common;

import java.util.List;

public interface FlightRepository {

	public List<Flight> getAvailableFlights();

}
