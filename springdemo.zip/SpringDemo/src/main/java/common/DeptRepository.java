package common;
import java.util.List;




public interface DeptRepository {

void addDepartment(Dept ref); 
// void updateDepartment(Dept ref); 
 void deleteDepartment(String dno);

//import java.util.List;



	public List<Dept> getAvailableDepts();

}
