package carshowroom;

import carfactory.Engine;

public class Car
{
	Engine eng;
	
	public Car(Engine e) {
		System.out.println("Car ctor");
		eng = e;
	}
	public void drive() {
		System.out.println("Lets drive the car...");
	}
}