package xml;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import common.Dept;
import common.DeptRepository;
//import common.Flight;
//import common.FlightRepository;

public class DeptRepositoryImpl implements DeptRepository {

	
	


		//CarEngine
		public DeptRepositoryImpl() {
			System.out.println("FlightRepositoryImpl() ctor..");
		}
		private DataSource dataSource; //driver/url/username/password
		
		public void setDataSource(DataSource d) {
			System.out.println("setDateSource(DataSource) setter method invoked...");
			this.dataSource = d;
		}

		public List<Dept> getAvailableDepts() {
			Connection conn = null;
			PreparedStatement pst = null;
			ResultSet rs = null;
			try {
				conn = dataSource.getConnection();
				String sql = "select * from Dept";
				pst = conn.prepareStatement(sql);
				rs = pst.executeQuery();
				
				List<Dept> rows = new ArrayList<Dept>();
				
				while(rs.next()) { //each row
					
					Dept f = new Dept(); //blank object
					
					f.setDno(rs.getString(1)); //fillup
					f.setDname(rs.getString(2));//fillup
					f.setLoc(rs.getString(3));//fillup
				//	f.setTo(rs.getString(4));//fillup
					
					rows.add(f); //store it in list
				}
				return rows;
			}
			catch(SQLException e) {
				throw new RuntimeException(e);
			}
			finally {
				try { rs.close(); pst.close(); conn.close(); } catch(Exception e) { 
					
					System.out.println("error "+e);
				}
			}
		}

		public void addDepartment(Dept ref) {
			Connection conn = null;
			PreparedStatement pst = null;
			ResultSet rs = null;
			try {
				
			

				conn = dataSource.getConnection();
				
				
				String sql="insert into dept values (?,?,?)";
		  pst = conn.prepareStatement(sql);
		  
		  pst.setString(1, ref.getDno());
		  pst.setString(2, ref.getDname());
		  pst.setString(3, ref.getLoc());
		  
		  pst.executeUpdate();
		  
			}
			catch(SQLException e) {
				throw new RuntimeException(e);
			}
			finally {
				try { rs.close(); pst.close(); conn.close(); } catch(Exception e) { 
					
					System.out.println("error "+e);
				}
			}
		 
		}

		

	//	public void updateDepartment(Dept ref) {
			// TODO Auto-generated method stub
			
	//	}

		public void deleteDepartment(String dno) {
			Connection conn = null;
			PreparedStatement pst = null;
			ResultSet rs = null;
			try {
				
			

				conn = dataSource.getConnection();
				
				
				String sql="delete from dept where deptno=?";
				 pst = conn.prepareStatement(sql);
				  
				//  pst.setString(1, ref.getDno());
				 // pst.setString(2, ref.getDname());
				 // pst.setString(3, ref.getLoc());
					pst.setString(1, dno);
				  
				  pst.executeUpdate();
				  
					}
					catch(SQLException e) {
						throw new RuntimeException(e);
					}
					finally {
						try { rs.close(); pst.close(); conn.close(); } catch(Exception e) { 
							
							System.out.println("error "+e);
		
						}
					}
}
}