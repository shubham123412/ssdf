package xml;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.sql.DataSource;

import common.Flight;
import common.FlightRepository;


/* 
 * IQ  FIQ  EmotionsIQ   SIQ
 * 
 * richdad.com
 * 	rich dad vs poor dad
 * Robert Kiyosaki
 * H
 * P
 * S
 * ES
 * MCAS
 * BBA
 * CDAC
 * 		
 * Employee
 * |
 * E   |	B (Atos)<--->B(Pampers) <---- Business
 * -----------
 * S   |    I <-- Very Large Scale Investor
 * |
 * self
 * employed
 * 
 */


// DataSource ds= new Spring-->DriverManagerDataSource();
// ds.setDriver..
// ds.setUrl
// ds.setuser..
// ds.setpass

//FlightRepositoryImpl  f = container.getBean("flirepo");

//f.setDataSource(ds);

/*
class Car1
{
	Car1(Engine e, Piston p) { }
}

class Car2
{
	Engine e;
	
	void setEngine(Engine ref) {
		e = ref;
	}
}*/

/*DataSource dataSource = new org.springframework.jdbc.datasource.DriverManagerDataSource();
 * dataSource.setURL();
 * dataSource.setDriver()
 * dataSource.setPassword()
 * 
FlightRepositoryImpl  fri = new FlightRepositoryImpl ();
fri.setDataSource(dataSource);
*/

class Pqr { }
class Abc
{
	Pqr pref;
	void fun(Pqr p) {
		pref = p;
	}
	void far( ) {
		//pref can be used here too
	}
}
class Test {
	void foo()
	{
		Pqr p = new Pqr();//we neet to prepare it
		Abc a = new Abc(); //since 
		a.fun(p); // fun is dependent on p
	}
}

//IoC
			//Car
public class FlightRepositoryImpl implements FlightRepository {

	//CarEngine
	public FlightRepositoryImpl() {
		System.out.println("FlightRepositoryImpl() ctor..");
	}
	private DataSource dataSource; //driver/url/username/password
	
	public void setDataSource(DataSource d) {
		System.out.println("setDateSource(DataSource) setter method invoked...");
		this.dataSource = d;
	}

	public List<Flight> getAvailableFlights() {
		Connection conn = null;
		PreparedStatement pst = null;
		ResultSet rs = null;
		try {
			conn = dataSource.getConnection();
			String sql = "select * from flights_test";
			pst = conn.prepareStatement(sql);
			rs = pst.executeQuery();
			
			List<Flight> rows = new ArrayList<Flight>();
			
			while(rs.next()) { //each row
				
				Flight f = new Flight(); //blank object
				
				f.setFlightNo(rs.getString(1)); //fillup
				f.setCarrier(rs.getString(2));//fillup
				f.setFrom(rs.getString(3));//fillup
				f.setTo(rs.getString(4));//fillup
				
				rows.add(f); //store it in list
			}
			return rows;
		}
		catch(SQLException e) {
			throw new RuntimeException(e);
		}
		finally {
			try { rs.close(); pst.close(); conn.close(); } catch(Exception e) { 
				
				System.out.println("error "+e);
			}
		}
	}
}
