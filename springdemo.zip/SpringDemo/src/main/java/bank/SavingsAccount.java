package bank;

public class SavingsAccount {
	public SavingsAccount() {
		System.out.println("SavingsAccount()...");
	}
	public void withdraW() {
		System.out.println("Withdrawing...");
	}
}
